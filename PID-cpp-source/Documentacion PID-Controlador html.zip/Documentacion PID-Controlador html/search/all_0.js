var searchData=
[
  ['compute',['Compute',['../classPID.html#a05a3258d4b553e7a121f7360ffe88065',1,'PID']]],
  ['controlador',['Controlador',['../classControlador.html',1,'Controlador'],['../classControlador.html#a17db08229680461d4d1a2110a92ccf78',1,'Controlador::Controlador()'],['../classControlador.html#a1edab4396e124e9f2655be07696105b1',1,'Controlador::Controlador(double Ts, int inputPin, int outputPin, double minOutput, double maxOutput)']]],
  ['controlador_2ecpp',['controlador.cpp',['../controlador_8cpp.html',1,'']]],
  ['controlador_2eh',['controlador.h',['../controlador_8h.html',1,'']]]
];
