var searchData=
[
  ['ts',['Ts',['../classControlador.html#ad4b219e4a8ab1439dc946c094c9eef79',1,'Controlador']]]
];
