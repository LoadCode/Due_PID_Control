var searchData=
[
  ['referencia',['referencia',['../classControlador.html#a4d4d5b5c6f6ca8bb8c363a2fd07b8f5b',1,'Controlador']]],
  ['res',['res',['../classPID.html#ae6d1add39ba2ae17f0ca5ca95e9baabc',1,'PID']]]
];
