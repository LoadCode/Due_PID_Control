var searchData=
[
  ['initresolution',['InitResolution',['../classPID.html#a589ac3230d53140ffcb7b8b92c36a2ac',1,'PID']]]
];
