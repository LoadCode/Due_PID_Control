var searchData=
[
  ['lectura',['Lectura',['../classControlador.html#a48e478cb08ace322d291fa271837e4c5',1,'Controlador::Lectura()'],['../classPID.html#a001e3d063616a17bd5e3b82e6fa0c751',1,'PID::Lectura()']]]
];
