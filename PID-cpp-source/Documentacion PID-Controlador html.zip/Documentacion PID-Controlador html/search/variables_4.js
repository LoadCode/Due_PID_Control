var searchData=
[
  ['pinentrada',['pinEntrada',['../classControlador.html#aa493374daea96a73521a374d48e02ab5',1,'Controlador']]],
  ['pinsalida',['pinSalida',['../classControlador.html#a4155cdf3e44f23bb79d0daee07a2b178',1,'Controlador']]],
  ['preverror',['prevError',['../classPID.html#a124047ca819e26199964de9c2c8f2dc0',1,'PID']]],
  ['prevsalidaplanta',['prevSalidaPlanta',['../classPID.html#a15ceb6d316cb248c1440bf57e8cfb3ef',1,'PID']]],
  ['pterm',['pTerm',['../classPID.html#af931212cc8de18013248e364ee7f6e26',1,'PID']]]
];
