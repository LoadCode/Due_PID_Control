var searchData=
[
  ['pid',['PID',['../classPID.html#a0311b6f7de348499ce24e53ba353514a',1,'PID::PID()'],['../classPID.html#ad5ef5f4377219bc903fbc2247f0c4856',1,'PID::PID(double Ts, int inputPin, int outputPin, double minOutput, double maxOutput)']]]
];
