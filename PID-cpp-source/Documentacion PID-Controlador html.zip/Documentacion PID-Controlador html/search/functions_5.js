var searchData=
[
  ['setinputpin',['SetInputPin',['../classControlador.html#a5ee09bd6c4e258e593ba6bd82ceeb6f4',1,'Controlador']]],
  ['setoutputpin',['SetOutputPin',['../classControlador.html#aec7e783903fad8abb5dd7f9e71c505f2',1,'Controlador']]],
  ['setpidparameters',['SetPIDParameters',['../classPID.html#a1f056825b745af594df77a9e892521af',1,'PID']]],
  ['setreferencia',['SetReferencia',['../classControlador.html#a9a176ad13731193c102a23395bdf7556',1,'Controlador']]],
  ['setsalidamaxima',['SetSalidaMaxima',['../classControlador.html#a23f8f408e4d82906cafc426229dfa572',1,'Controlador']]],
  ['setsalidaminima',['SetSalidaMinima',['../classControlador.html#a70a442140015d10d5ddb195789404774',1,'Controlador']]],
  ['setsampletime',['SetSampleTime',['../classControlador.html#a108e98f0fad8705912a64fdad9f1b96a',1,'Controlador::SetSampleTime()'],['../classPID.html#ae71128f4590500fe5135e62e7892913e',1,'PID::SetSampleTime()']]]
];
