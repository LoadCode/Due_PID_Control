var searchData=
[
  ['escritura',['Escritura',['../classControlador.html#a23ac86a407bdd8295a7af0ac38e6a3d5',1,'Controlador::Escritura()'],['../classPID.html#a0f0ca87d86c2237c9e85db1513251783',1,'PID::Escritura()']]]
];
